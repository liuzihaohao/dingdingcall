from setuptools import setup

setup(
	name='dingdingcall',
	author='liuzihao',
	version='1.0',
	py_modules=['dingdingcall'],
	install_requires=['requests','time','hmac','hashlib','base64','urllib']
)